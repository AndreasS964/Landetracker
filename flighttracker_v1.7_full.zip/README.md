# Flighttracker v1.7

Ein lokaler ADS-B-Flugtracker für den Raspberry Pi mit Web-Frontend, Kartenansicht und SQLite-Datenbank.

## Features

- Datenquelle: lokal (readsb) + optional OpenSky
- Speicherung in SQLite inkl. Koordinaten
- Web-Frontend mit Bootstrap, Leaflet & DataTables
- Exakte Platzrunde (GPX-basiert)
- API-Filter: `/api/flights?alt=3000&date=YYYY-MM-DD`
- Export als CSV oder JSON: `/export?format=csv&from=...&to=...`
- Live-Refresh der Anzeige alle 60s
- Logging in Datei + Web-Loganzeige
- Automatischer Daten-Cleanup nach 180 Tagen
- Kompatibel mit tar1090 & graphs1090

## Start

```bash
python3 flighttracker.py
```

Weboberfläche: [http://localhost:8083](http://localhost:8083)

## Lizenz

MIT License
