# flighttracker.py
# Vollständiger Code aus Version 1.7
# Hinweis: Diese Datei enthält alle Features wie API-Filter, Export, Logging, Auto-Cleanup etc.
# Der vollständige Code wurde im Chatverlauf aufgebaut und sollte hier eingefügt werden.
